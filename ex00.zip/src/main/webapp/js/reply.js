/**
 * 게시판 댓글 처리에 필요한 JS(Jquery)
 */
 
 
 //브라우저의 콘솔 탭에 출력한다.
 console.log("Reply Module ......");
 
 // replyService 변수 - 타입은 Object -JSON


 var replyService = (
 	function(){
 		function list(param, callback, error){
 			var no = param.no;
 			var page = param.repPage || 1;
 			var perPageNum = param.repPerPageNum || 5;
 			
 			// Ajax를 이용한 데이터 가져오기
 			
 		}
 		
 		return{
 			//replyService.list(param.callback)
 			list : list
 		}
 	}
 		
 )();
 console.log(replyService);
 
